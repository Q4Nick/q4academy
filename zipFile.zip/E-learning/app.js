const modules = [
  {
    id: "disc",
    title: "DISC",
    summary: "Module voor gedragsvoorkeuren, DISC-basiskennis en het Persoonlijke Stijl (DISC) Profiel.",
    planned: "Binnen deze module kunnen later extra DISC-cursussen worden toegevoegd. Het platform blijft ook geschikt voor nieuwe modules naast DISC.",
  },
];

const courses = [
  {
    id: 1,
    moduleId: "disc",
    title: "Cursus 1: De basis van DISC",
    summary:
      "De startcursus binnen de module DISC. De deelnemer leert de basis van menselijk gedrag, de brug naar DISC en de kern van het DISC-model.",
    duration: "70 min",
    progress: 100,
    factcards: 6,
    trainerQuestions: 19,
    quizCorrect: 14,
    quizTotal: 14,
    lessons: [
      {
        id: "1-1",
        title: "De basis van menselijk gedrag",
        minutes: 24,
        steps: 16,
        quiz: "4/4",
        intro:
          "Introductieles over menselijk gedrag. In de uiteindelijke cursus kan deze les worden opgebouwd uit video, tekst, reflectie en korte kennischecks.",
      },
      {
        id: "1-2",
        title: "Van menselijk gedrag naar DISC",
        media: "Video masterclass gedrag, brein en Maslow-piramide",
        minutes: 23,
        steps: 17,
        quiz: "6/6",
        intro:
          "Deze les vormt de brug van algemeen menselijk gedrag naar DISC. De video masterclass over gedrag, brein en Maslow-piramide is een kernonderdeel.",
      },
      {
        id: "1-3",
        title: "De basis van DISC",
        minutes: 23,
        steps: 13,
        quiz: "4/4",
        intro:
          "De deelnemer leert de basis van DISC kennen en bereidt zich voor op de trainer quiz van cursus 1.",
      },
    ],
  },
  {
    id: 2,
    moduleId: "disc",
    title: "Cursus 2: Van DISC naar het Persoonlijke Stijl (DISC) Profiel",
    summary:
      "Vervolgcursus binnen de module DISC. Deelnemers verdiepen de temperamenten, meting, grafiek en opbouw van het Persoonlijke Stijl (DISC) Profiel.",
    duration: "72 min",
    progress: 100,
    factcards: 4,
    trainerQuestions: 20,
    quizCorrect: 19,
    quizTotal: 19,
    lessons: [
      {
        id: "2-1",
        title: "De vier fundamentele temperamenten",
        minutes: 24,
        steps: 16,
        quiz: "6/6",
        intro:
          "De deelnemer verdiept zich in de vier fundamentele temperamenten en leert deze herkennen in gedrag.",
      },
      {
        id: "2-2",
        title: "Van DISC naar het Persoonlijke Stijl (DISC) Profiel",
        media: "Video meting en grafiek",
        minutes: 24,
        steps: 15,
        quiz: "6/6",
        intro:
          "Deze les maakt de vertaalslag van DISC naar het Persoonlijke Stijl (DISC) Profiel. De video over meting en grafiek is een kernonderdeel.",
      },
      {
        id: "2-3",
        title: "Opbouw van het Persoonlijke Stijl (DISC) Profiel",
        minutes: 24,
        steps: 17,
        quiz: "7/7",
        intro:
          "De deelnemer leert hoe het Persoonlijke Stijl (DISC) Profiel is opgebouwd en hoe de onderdelen logisch samenhangen.",
      },
    ],
  },
];

const factcards = [
  ["theorie", "Motivatiepiramide", "Een korte uitleg over hoe basisbehoeften invloed hebben op leer- en werkgedrag.", 1],
  ["stijl", "Directe voorkeursstijl", "Kenmerken, valkuilen en praktische gespreksaanpak voor doelgerichte deelnemers.", 1],
  ["stijl", "Expressieve voorkeursstijl", "Herken enthousiasme, invloed en sociale energie in groepssituaties.", 1],
  ["stijl", "Stabiele voorkeursstijl", "Een overzicht van rust, betrouwbaarheid en behoefte aan voorspelbaarheid.", 1],
  ["stijl", "Analytische voorkeursstijl", "Praktische signalen rondom kwaliteit, kaders en zorgvuldig werken.", 1],
  ["team", "Waarde in het team", "Een compacte kaart over bijdrage, risico en samenwerking per voorkeur.", 1],
  ["communicatie", "Gesprekschecklist", "Vragen en observaties om een profielgesprek veilig en helder te voeren.", 2],
  ["profiel", "Zestien combinaties", "Een beknopt overzicht van gecombineerde gedragsvoorkeuren.", 2],
  ["theorie", "De meting", "Hoe vragenlijsten worden vertaald naar bruikbare profielinformatie.", 2],
  ["profiel", "Energie en aanpassing", "Signalen die kunnen wijzen op spanning, herstel of rolverwachting.", 2],
];

const users = [
  ["Demo Admin", "admin@learninghub.test", "Admin", "Volledig", "Actief", "Vandaag"],
  ["Demo Student", "student@learninghub.test", "Student", "Trial", "Inactief", "Nooit"],
  ["Course Learner", "course@learninghub.test", "Student", "Cursus 1", "Inactief", "12 dagen"],
  ["Full Learner", "full@learninghub.test", "Student", "Volledig", "Inactief", "32 dagen"],
];

const app = document.querySelector("#app");
const state = {
  route: "login",
  activeCourse: 1,
  activeLesson: "1-1",
  step: 1,
  selectedAnswer: "",
  adminTab: "overview",
  modal: null,
};

function icon(name) {
  const paths = {
    mail: '<path d="M3 6h18v12H3z"/><path d="m3 7 9 6 9-6"/>',
    arrow: '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
    play: '<path d="M8 5v14l11-7z"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    book: '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21z"/><path d="M4 5v16"/>',
  };
  return `<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${paths[name]}</svg>`;
}

function courseById(id = state.activeCourse) {
  return courses.find((course) => course.id === Number(id)) || courses[0];
}

function lessonById(id = state.activeLesson) {
  return courses.flatMap((course) => course.lessons.map((lesson) => ({ ...lesson, courseId: course.id }))).find((lesson) => lesson.id === id);
}

function navigate(route, patch = {}) {
  Object.assign(state, patch, { route });
  render();
}

function shell(content, section = "") {
  const authed = state.route !== "login";
  return `
    <div class="shell">
      <div class="stripe"><span></span><span></span><span></span><span></span></div>
      <header class="topbar">
        <div class="topbar-inner">
          <button class="brand" data-route="${authed ? "dashboard" : "login"}">
            <span class="brand-mark" aria-hidden="true"></span>
            <span><span class="brand-title">Learning Hub</span><span class="brand-subtitle">E-learning Prototype</span></span>
          </button>
          ${authed ? nav(section) : `<div class="language"><button class="active">NL</button><button>EN</button></div>`}
        </div>
      </header>
      ${content}
      ${state.modal ? modal() : ""}
    </div>
  `;
}

function nav(section) {
  const items = [
    ["dashboard", "Dashboard"],
    ["factcards", "Factcards"],
    ["progress", "Voortgang"],
    ["admin", "Admin"],
  ];
  return `
    <div class="top-actions">
      <nav class="nav">
        ${items.map(([route, label]) => `<button class="${section === route ? "active" : ""}" data-route="${route}">${label}</button>`).join("")}
      </nav>
      <div class="language"><button class="active">NL</button><button>EN</button></div>
      <button class="avatar" data-modal="profile" title="Profiel">AG</button>
    </div>
  `;
}

function loginView() {
  return shell(`
    <main class="login-layout">
      <section class="login-hero">
        <div class="shape red"></div>
        <div class="shape orange"></div>
        <div class="shape green"></div>
        <div class="hero-copy">
          <h1>Persoonlijke <span class="green-word">groei</span> wordt zichtbaar in <span class="blue-word">actie</span></h1>
          <p>Een prototype voor een compacte leeromgeving met cursussen, lessen, trainers, voortgang en beheer.</p>
          <ul class="ticks">
            <li><span class="tick">OK</span> Modulaire lessen met voortgang</li>
            <li><span class="tick">OK</span> Kennischecks en trainers</li>
            <li><span class="tick">OK</span> Beheer voor toegang en uitnodigingen</li>
          </ul>
        </div>
      </section>
      <section class="login-panel">
        <div>
          <form class="auth-card" data-login>
            <h2>Welkom terug</h2>
            <p>Vul je e-mailadres in om door te gaan.</p>
            <div class="field">
              <label for="email">E-mailadres</label>
              <div class="input-wrap">${icon("mail")}<input id="email" type="email" value="demo@learninghub.test" required /></div>
            </div>
            <button class="btn full" type="submit">Inloggen met e-mail ${icon("arrow")}</button>
          </form>
          <p class="helper">Geen account? Vraag je beheerder om een uitnodiging.</p>
        </div>
      </section>
    </main>
  `);
}

function dashboardView() {
  const totalLessons = courses.reduce((sum, course) => sum + course.lessons.length, 0);
  const activeModule = modules[0];
  return shell(`
    <main class="main">
      <div class="page-head">
        <div><h1>${activeModule.title}</h1><p>${activeModule.summary}</p></div>
      </div>
      <section class="metrics">
        ${metric("Modules", modules.length)}
        ${metric("Cursussen", courses.length)}
        ${metric("Voltooid", `${totalLessons}/${totalLessons}`)}
        ${metric("Lessen", totalLessons)}
      </section>
      <div class="section-title"><h2>Cursussen binnen ${activeModule.title}</h2><span>${courses.length} cursussen nu, uitbreiding voorzien</span></div>
      <section class="course-grid">
        ${courses.map(courseCard).join("")}
      </section>
      <div class="section-title"><h2>Toekomstige uitbreiding</h2></div>
      <section class="card" style="padding:18px"><p>${activeModule.planned}</p></section>
    </main>
  `, "dashboard");
}

function metric(label, value) {
  return `<div class="metric"><small>${label}</small><strong>${value}</strong></div>`;
}

function courseCard(course) {
  return `
    <button class="card course-card" data-course="${course.id}">
      <div class="course-art" aria-hidden="true"></div>
      <div>
        <h3>${course.title}</h3>
        <p>${course.summary}</p>
        <div class="meta-row"><span>${course.lessons.length} lessen</span><span>${course.duration}</span><span>${course.lessons.length} van ${course.lessons.length} lessen</span></div>
      </div>
      <div class="progress-box">
        <strong>${course.progress}%</strong>
        <div class="progress-track"><div class="progress-fill" style="width:${course.progress}%"></div></div>
        <span class="btn secondary">Bekijk opnieuw</span>
      </div>
    </button>
  `;
}

function courseView() {
  const course = courseById();
  return shell(`
    <main class="main">
      <button class="breadcrumb" data-route="dashboard">Terug naar dashboard</button>
      <div class="page-head">
        <div><h1>${course.title}</h1><p>${course.summary}</p></div>
      </div>
      <section class="metrics">
        ${metric("Lessen", course.lessons.length)}
        ${metric("Voltooid", course.lessons.length)}
        ${metric("Voortgang", `${course.progress}%`)}
        ${metric("Factcards", course.factcards)}
      </section>
      <div class="course-detail-grid">
        <section>
          <div class="section-title"><h2>Lessen</h2><span>${course.lessons.length} van ${course.lessons.length} lessen voltooid</span></div>
          <div class="lessons">
            ${course.lessons.map((lesson, index) => lessonRow(lesson, index, course.id)).join("")}
          </div>
        </section>
        <aside class="side-stack">
          <div class="card">
            <span class="tag">Timed Quiz</span>
            <h3>Trainer</h3>
            <p>Test je kennis met directe feedback en vrije navigatie.</p>
            <div class="meta-row"><span>${course.trainerQuestions} vragen</span><span>80% vereist</span></div>
            <button class="btn full" data-trainer="${course.id}">${icon("play")} Start trainer</button>
          </div>
          <div class="card">
            <span class="tag">Naslag</span>
            <h3>Factcards</h3>
            <p>Bekijk ${course.factcards} kaarten die bij deze cursus horen.</p>
            <button class="btn secondary full" data-fact-filter="${course.id}">${icon("book")} Bekijk factcards</button>
          </div>
        </aside>
      </div>
    </main>
  `, "dashboard");
}

function lessonRow(lesson, index, courseId) {
  return `
    <button class="card lesson-row" data-lesson="${lesson.id}" data-course-id="${courseId}">
      <span class="lesson-index">Les ${index + 1}</span>
      <span><strong>${lesson.title}</strong><span class="meta-row"><span>${lesson.minutes} min</span><span>Quiz ${lesson.quiz}</span></span></span>
      <span class="badge">Voltooid</span>
    </button>
  `;
}

function lessonView() {
  const lesson = lessonById();
  const course = courseById(lesson.courseId);
  const step = Math.min(state.step, lesson.steps);
  const isQuizStep = step % 5 === 0;
  return shell(`
    <main class="main">
      <div class="lesson-shell">
        <aside class="step-rail">
          ${Array.from({ length: lesson.steps }, (_, i) => `<button class="step-dot ${i + 1 < step ? "done" : ""} ${i + 1 === step ? "active" : ""}" data-step="${i + 1}">${i + 1}</button>`).join("")}
        </aside>
        <section class="lesson-content">
          <header class="lesson-header">
            <button class="breadcrumb" data-course="${course.id}">Terug naar cursus</button>
            <h1>${lesson.title}</h1>
            <p>${lesson.intro}</p>
            <div class="meta-row"><span>Stap ${step} van ${lesson.steps}</span><span>Quiz: ${lesson.quiz} correct</span></div>
          </header>
          <div class="lesson-body">
            ${isQuizStep ? quizBlock() : contentBlock(step)}
          </div>
          <footer class="lesson-footer">
            <button class="btn ghost" data-course="${course.id}">Afsluiten</button>
            <div>
              <button class="btn ghost" data-prev-step ${step === 1 ? "disabled" : ""}>Vorige</button>
              <button class="btn" data-next-step>${step === lesson.steps ? "Les afronden" : "Volgende"} ${icon("arrow")}</button>
            </div>
          </footer>
        </section>
      </div>
    </main>
  `, "dashboard");
}

function contentBlock(step) {
  const lesson = lessonById();
  const mediaLabel = lesson.media || "Video / interactieve uitleg";
  return `
    <div class="media-block">${icon("play")} ${mediaLabel}</div>
    <div class="quiz-card">
      <span class="tag">Stap ${step}</span>
      <h3>Leerblok met praktijkvoorbeeld</h3>
      <p>Hier staat in het echte product de lesinhoud. In dit prototype blijft de inhoud neutraal en gaat het om de UX: lezen, kijken, navigeren en korte checks uitvoeren.</p>
    </div>
  `;
}

function quizBlock() {
  const options = ["Observatie", "Interpretatie", "Actieplan"];
  return `
    <div class="quiz-card">
      <span class="tag">Kennischeck</span>
      <h3>Welke stap past het beste bij deze situatie?</h3>
      <p>Kies een antwoord om de directe feedbackstaat te zien.</p>
      <div class="quiz-options">
        ${options.map((option) => `<button class="${state.selectedAnswer === option ? "selected" : ""}" data-answer="${option}">${option}</button>`).join("")}
      </div>
      ${state.selectedAnswer ? `<p class="badge">Antwoord opgeslagen</p>` : ""}
    </div>
  `;
}

function trainerView() {
  const course = courseById();
  return shell(`
    <main class="main">
      <button class="breadcrumb" data-course="${course.id}">Terug naar ${course.title}</button>
      <section class="trainer-panel">
        <span class="tag">Timed Quiz</span>
        <div class="page-head">
          <div><h1>Trainer quiz ${course.title.replace("Cursus ", "cursus ")}</h1><p>Test je kennis met een korte trainer.</p></div>
        </div>
        <section class="metrics">
          ${metric("Vragen", course.trainerQuestions)}
          ${metric("Vereist", "80%")}
          ${metric("Beste score", "100%")}
          ${metric("Tijd", "03:24")}
        </section>
        <div class="trainer-features">
          <div class="feature"><strong>${icon("clock")} Timer loopt</strong><p>De tijd wordt bijgehouden zodra je start.</p></div>
          <div class="feature"><strong>Vrij navigeren</strong><p>Ga terug naar eerdere vragen wanneer nodig.</p></div>
          <div class="feature"><strong>Direct feedback</strong><p>Zie direct of je antwoord klopt.</p></div>
        </div>
        <button class="btn" data-modal="trainer">Start de trainer</button>
      </section>
    </main>
  `, "dashboard");
}

function factcardsView(filterCourse) {
  const list = filterCourse ? factcards.filter((card) => card[3] === Number(filterCourse)) : factcards;
  return shell(`
    <main class="main">
      <div class="page-head">
        <div><h1>Factcards</h1><p>Korte naslagkaarten per thema en cursus.</p></div>
      </div>
      <section class="factcard-grid">
        ${list.map(([tag, title, text], index) => `
          <button class="card factcard" data-modal="factcard-${index}">
            <span class="tag">${tag}</span>
            <h3>${title}</h3>
            <p>${text}</p>
          </button>
        `).join("")}
      </section>
    </main>
  `, "factcards");
}

function progressView() {
  return shell(`
    <main class="main">
      <div class="page-head"><div><h1>Mijn voortgang</h1><p>Bekijk voortgang en prestaties.</p></div></div>
      <section class="metrics">
        ${metric("Totale voortgang", "100%")}
        ${metric("Lessen voltooid", "6/6")}
        ${metric("Bestede tijd", "13u 35m")}
        ${metric("Quizscore", "100%")}
      </section>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Cursus</th><th>Voortgang</th><th>Tijd</th><th>Quiz</th></tr></thead>
          <tbody>
            ${courses.map((course) => `<tr><td>${course.title}</td><td>${course.progress}%</td><td>${course.duration}</td><td>${course.quizCorrect}/${course.quizTotal}</td></tr>`).join("")}
          </tbody>
        </table>
      </div>
    </main>
  `, "progress");
}

function adminView() {
  return shell(`
    <main class="main">
      <div class="tabs">
        ${["overview", "users", "invites"].map((tab) => `<button class="${state.adminTab === tab ? "active" : ""}" data-admin-tab="${tab}">${tab === "overview" ? "Overzicht" : tab === "users" ? "Gebruikers" : "Uitnodigingen"}</button>`).join("")}
      </div>
      ${state.adminTab === "overview" ? adminOverview() : state.adminTab === "users" ? adminUsers() : adminInvites()}
    </main>
  `, "admin");
}

function adminOverview() {
  return `
    <div class="page-head"><div><h1>Overzicht</h1><p>Beheer toegang, uitnodigingen en leerresultaten.</p></div></div>
    <section class="admin-grid">
      ${metric("Gebruikers", 11)}
      ${metric("Uitnodigingen", 18)}
      ${metric("Cursusvoltooiing", "70%")}
      ${metric("Quizscore", "75%")}
    </section>
  `;
}

function adminUsers() {
  return `
    <div class="page-head"><div><h1>Gebruikersbeheer</h1><p>Beheer gebruikers en toegangsniveaus.</p></div><button class="btn" data-modal="invite">Nieuwe uitnodiging</button></div>
    <div class="table-wrap"><table><thead><tr><th>Naam</th><th>Email</th><th>Rol</th><th>Toegang</th><th>Status</th><th>Laatste login</th></tr></thead><tbody>
      ${users.map((user) => `<tr>${user.map((cell) => `<td>${cell}</td>`).join("")}</tr>`).join("")}
    </tbody></table></div>
  `;
}

function adminInvites() {
  const rows = [
    ["learner1@example.test", "Volledig", "Gebruikt", "12-6-2026", "19-6-2026"],
    ["learner2@example.test", "Trial", "Verlopen", "8-6-2026", "15-6-2026"],
    ["learner3@example.test", "Cursus 1", "Openstaand", "3-6-2026", "10-6-2026"],
  ];
  return `
    <div class="page-head"><div><h1>Uitnodigingen</h1><p>Nodig nieuwe gebruikers uit voor het platform.</p></div><button class="btn" data-modal="invite">Uitnodigen</button></div>
    <div class="table-wrap"><table><thead><tr><th>Email</th><th>Toegang</th><th>Status</th><th>Aangemaakt</th><th>Verloopt</th></tr></thead><tbody>
      ${rows.map((row) => `<tr>${row.map((cell) => `<td>${cell}</td>`).join("")}</tr>`).join("")}
    </tbody></table></div>
  `;
}

function modal() {
  const copy = {
    profile: ["Profiel", "Hier zou de gebruiker zijn profiel, taalvoorkeur en uitlogactie beheren."],
    trainer: ["Trainer gestart", "In het echte product opent hier de getimede vragenflow met voortgang, timer en directe feedback."],
    invite: ["Nieuwe uitnodiging", "Dit prototype simuleert het uitnodigingsformulier zonder gegevens te versturen."],
  }[state.modal] || ["Factcard", "Hier opent een verdiepende naslagkaart met gerelateerde lessen en aanvullende uitleg."];
  return `<div class="modal-backdrop" data-close-modal><div class="modal-card" role="dialog" aria-modal="true"><h2>${copy[0]}</h2><p>${copy[1]}</p><button class="btn" data-close-modal>Sluiten</button></div></div>`;
}

function render() {
  const views = {
    login: loginView,
    dashboard: dashboardView,
    course: courseView,
    lesson: lessonView,
    trainer: trainerView,
    factcards: () => factcardsView(state.factFilter),
    progress: progressView,
    admin: adminView,
  };
  app.innerHTML = (views[state.route] || dashboardView)();
}

document.addEventListener("click", (event) => {
  const target = event.target.closest("button,a");
  if (!target) return;
  const route = target.dataset.route;
  const courseId = target.dataset.course;
  const lessonId = target.dataset.lesson;
  const trainerId = target.dataset.trainer;
  const step = target.dataset.step;
  const answer = target.dataset.answer;
  const tab = target.dataset.adminTab;
  const modalId = target.dataset.modal;
  const filter = target.dataset.factFilter;

  if (route) navigate(route);
  if (courseId) navigate("course", { activeCourse: Number(courseId), factFilter: null });
  if (lessonId) navigate("lesson", { activeLesson: lessonId, activeCourse: Number(target.dataset.courseId), step: 1, selectedAnswer: "" });
  if (trainerId) navigate("trainer", { activeCourse: Number(trainerId) });
  if (filter) navigate("factcards", { factFilter: Number(filter) });
  if (step) navigate("lesson", { step: Number(step), selectedAnswer: "" });
  if (target.hasAttribute("data-prev-step")) navigate("lesson", { step: Math.max(1, state.step - 1), selectedAnswer: "" });
  if (target.hasAttribute("data-next-step")) {
    const lesson = lessonById();
    if (state.step >= lesson.steps) navigate("course", { activeCourse: lesson.courseId });
    else navigate("lesson", { step: state.step + 1, selectedAnswer: "" });
  }
  if (answer) navigate("lesson", { selectedAnswer: answer });
  if (tab) navigate("admin", { adminTab: tab });
  if (modalId) navigate(state.route, { modal: modalId });
  if (target.hasAttribute("data-close-modal")) navigate(state.route, { modal: null });
});

document.addEventListener("submit", (event) => {
  if (event.target.matches("[data-login]")) {
    event.preventDefault();
    navigate("dashboard");
  }
});

render();
